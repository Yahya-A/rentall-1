<!-- About Section -->
<section class="page-section bg-primary text-white mb-0 mt-5 " style="min-height:514px;">
    <div class="container">
        <div class="row">
            <div class="col-6 offset-3">
                <h2 class="page-section-heading text-center text-uppercase text-white my-5">Tentang RentALL</h2>
                <div class="card text-dark p-2">
                    <h6>RentALL terinspirasi dari banyaknya jasa persewaan yang kurang dalam hal sistemnya. Maka kami membuat website ini.</h6>
                    <h6>Website ini dibuat pada tahun 2020 dan mengutamakan tentang keutamaan dari pihak pemilik dan penyewa.</h6>
                </div>
            </div>
        </div>
    </div>
</section>